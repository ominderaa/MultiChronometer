package nl.motonono.multichronometer.run;


import static nl.motonono.multichronometer.model.Chronometer.ChronoState.CS_IDLE;
import static nl.motonono.multichronometer.model.Chronometer.ChronoState.CS_RUNNING;

import android.graphics.Color;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import nl.motonono.multichronometer.R;
import nl.motonono.multichronometer.model.ChronoManager;
import nl.motonono.multichronometer.model.Chronometer;
import nl.motonono.multichronometer.utils.TimeFormatter;

public class RunListAdapter extends RecyclerView.Adapter<RunListAdapter.ViewHolder> {

    private ChronoManager chronomanager;

    // RecyclerView recyclerView;
    public RunListAdapter(ChronoManager chronoman) {
        this.chronomanager = chronoman;
    }

    @Override
    public RunListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.chrono_item, parent, false);
        RunListAdapter.ViewHolder viewHolder = new RunListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RunListAdapter.ViewHolder holder, int position) {
        final Chronometer myChrono = chronomanager.getChronos().get(position);
        holder.setPosition(position);
        holder.mChronoName.setText(myChrono.getName());
        holder.mLapCount.setText(String.format("%02d", myChrono.getLapcount()));
        holder.mLastLaptime.setText(TimeFormatter.toText(myChrono.getLastLaptime()));
        holder.mTotalTime.setText(TimeFormatter.toText(myChrono.getTotalTime()));
        holder.mCurrentTime.setText(TimeFormatter.toText(myChrono.getCurrentTime()));

        if(myChrono.getState() == Chronometer.ChronoState.CS_COUNTDOWN) {
            holder.mTotalTime.setTextColor(Color.RED);
        } else {
            holder.mTotalTime.setTextColor(Color.BLACK);
        }

        holder.mLapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Chronometer myChrono = chronomanager.getChronos().get(holder.getAdapterPosition());
                if(myChrono.getState() == CS_RUNNING) {
                    myChrono.lap();
                }
                if(myChrono.getState() == CS_IDLE) {
                    myChrono.startAt(SystemClock.elapsedRealtime());
                    holder.mLapbutton.setText(R.string.lap);
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return chronomanager.getChronos().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public int position;
        public TextView mChronoName;
        public TextView mLapCount;
        public TextView mLastLaptime;
        public TextView mTotalTime;
        public TextView mCurrentTime;
        public Button mLapbutton;

        public ViewHolder(View itemView) {
            super(itemView);
            this.mChronoName = (TextView) itemView.findViewById(R.id.txChronoName);
            this.mLapCount = (TextView) itemView.findViewById(R.id.txLapcount);
            this.mLastLaptime = (TextView) itemView.findViewById(R.id.txLastlap);
            this.mTotalTime = (TextView) itemView.findViewById(R.id.txTotalTime);
            this.mCurrentTime = (TextView) itemView.findViewById(R.id.txCurrentTime);
            this.mLapbutton = (Button) itemView.findViewById(R.id.btnLap);
        }

        public void setPosition(int position) {
            this.position = position;
        }
    }


}
