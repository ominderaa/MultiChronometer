package nl.motonono.multichronometer.utils;

import java.text.DecimalFormat;

public class TimeFormatter {
    public static synchronized String toText(long timeElapsed) {
        long timetoFormat = timeElapsed;
        if (timeElapsed < 0) timetoFormat = -timeElapsed;
        DecimalFormat df = new DecimalFormat("00");

        int hours = (int) (timetoFormat / (3600 * 1000));
        int remaining = (int) (timetoFormat % (3600 * 1000));

        int minutes = (int) (remaining / (60 * 1000));
        remaining = (int) (remaining % (60 * 1000));

        int seconds = (int) (remaining / 1000);
        remaining = (int) (remaining % (1000));

        int milliseconds = (int) (((int) timetoFormat % 1000) / 10);
        String text = "";
        if (hours > 0) {
            text += df.format(hours) + ":";
            text += df.format(minutes) + ".";
            text += df.format(seconds);
        } else if (minutes > 0) {
            text += df.format(minutes) + ":";
            text += df.format(seconds) + ".";
            text += df.format(milliseconds);
        } else  {
            text += df.format(seconds) + ".";
            text += df.format(milliseconds);
        }
        return text;
    }
}
