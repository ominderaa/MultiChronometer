package nl.motonono.multichronometer.run;

import static nl.motonono.multichronometer.model.ChronoManager.RunMode.ONE_BY_ONE;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Timer;
import java.util.TimerTask;

import nl.motonono.multichronometer.R;
import nl.motonono.multichronometer.databinding.FragmentRunBinding;
import nl.motonono.multichronometer.model.ChronoManager;
import nl.motonono.multichronometer.startup.StartupFragment;

public class RunFragment extends Fragment {

    private FragmentRunBinding binding;
    private RunListAdapter runListAdapter;
    private Timer mUpdateTimer = new Timer();

    private Handler mHandler  = new Handler() {
        public void handleMessage(Message msg) {
            ChronoManager.instance().tick();
        for ( int i = 0; i < ChronoManager.instance().getChronos().size(); i++) {
            runListAdapter.notifyItemChanged(i);
        }
        }
    };

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState ) {
        binding = FragmentRunBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.btnStop.setVisibility(View.INVISIBLE);

        switch( ChronoManager.instance().getRunmode() ) {
            case ALL_AT_ONCE:
                binding.btnStartChrono.setVisibility(View.VISIBLE);
                break;
            case TIMED_INTERVAL:
                binding.btnStartChrono.setVisibility(View.VISIBLE);
                break;
            case ONE_BY_ONE:
                binding.btnStartChrono.setVisibility(View.GONE);
                break;
        }

        binding.btnStartChrono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChronoManager.instance().start();
                if(ChronoManager.instance().getRunmode() != ONE_BY_ONE) {
                    binding.btnStartChrono.setVisibility(View.GONE);
                    binding.btnStop.setVisibility(View.VISIBLE);
                }
            }
        });

        binding.btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChronoManager.instance().stop();
                NavHostFragment.findNavController(RunFragment.this)
                        .navigate(R.id.action_RunFragment_to_ResultsFragment);
            }
        });

        RecyclerView runRecyclerView = (RecyclerView) view.findViewById(R.id.runListView);
        runListAdapter = new RunListAdapter(ChronoManager.instance());
        if(runRecyclerView != null ) {
            runRecyclerView.setHasFixedSize(true);
            runRecyclerView.setLayoutManager(new LinearLayoutManager(null));
            runRecyclerView.setAdapter(runListAdapter);
        }

        mUpdateTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                mHandler.obtainMessage(1).sendToTarget();
            }
        }, 50, 100);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}