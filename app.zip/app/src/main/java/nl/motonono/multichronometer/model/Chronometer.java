package nl.motonono.multichronometer.model;

import android.os.SystemClock;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Chronometer {
    private int     id;
    private String  name;
    private List<Long> mLaptimes;

    public enum ChronoState {
        CS_IDLE,
        CS_RUNNING,
        CS_HALTED,
        CS_COUNTDOWN
    }
    private ChronoState mChronoState = ChronoState.CS_IDLE;
    private long mStartedAt;
    private long mStoppedAt;

    public Chronometer(int id, String name) {
        this.id = id;
        this.name = name;
        mLaptimes = new ArrayList<>();
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getLapcount() {
        return mLaptimes.size();
    }

    public long getCurrentTime() {
        if(mChronoState == ChronoState.CS_RUNNING)
            return SystemClock.elapsedRealtime() - mStartedAt;
        else
            return 0L;
    }

    public long getTotalTime() {
        if(mChronoState == ChronoState.CS_RUNNING) {
            if (mLaptimes.size() == 0) {
                return 0;
            } else if (mLaptimes.size() == 1) {
                return mLaptimes.get(0);
            }
            int lastidx = mLaptimes.size() - 1;
            return mLaptimes.get(lastidx);
        } else if(mChronoState == ChronoState.CS_COUNTDOWN) {
            return mStartedAt - SystemClock.elapsedRealtime();
        } else if(mChronoState == ChronoState.CS_HALTED) {
            return mStoppedAt-mStartedAt;
        }
        return 0L;
    }

    public long getLaptime(int lapnr) {
        if( lapnr < mLaptimes.size() )
            return mLaptimes.get(lapnr);
        else
            return 0L;
    }

    public ChronoState getState() {
        return mChronoState;
    }

    public long getLastLaptime() {
        if(mLaptimes.size() == 0 ) {
            return 0;
        }
        else if(mLaptimes.size() == 1 ) {
            return mLaptimes.get(0);
        }
        int lastidx = mLaptimes.size() - 1;
        return mLaptimes.get(lastidx) - mLaptimes.get(lastidx-1);
    }

    public List<Long> getLaptimes() { return mLaptimes; }

//    public synchronized String toText(long timeElapsed) {
//        long timetoFormat = timeElapsed;
//        if( timeElapsed < 0 ) timetoFormat = -timeElapsed;
//        DecimalFormat df = new DecimalFormat("00");
//
//        int hours = (int) (timetoFormat / (3600 * 1000));
//        int remaining = (int) (timetoFormat % (3600 * 1000));
//
//        int minutes = (int) (remaining / (60 * 1000));
//        remaining = (int) (remaining % (60 * 1000));
//
//        int seconds = (int) (remaining / 1000);
//        remaining = (int) (remaining % (1000));
//
//        int milliseconds = (int) (((int) timetoFormat % 1000) / 100);
//        String text = "";
//        if (hours > 0) {
//            text += df.format(hours) + ":";
//            text += df.format(minutes) + ".";
//            text += df.format(seconds);
//        } else {
//            text += df.format(minutes) + ":";
//            text += df.format(seconds) + ".";
//            text += df.format(milliseconds);
//        }
//
//        return text;
//    }

    public void startAt(long millis) {
        mStartedAt = millis;
        mChronoState = ChronoState.CS_RUNNING;
    }

    public void startIn(long millis) {
        mStartedAt = millis;
        mChronoState = ChronoState.CS_COUNTDOWN;
    }

    public void stop() {
        mChronoState = ChronoState.CS_HALTED;
        mStoppedAt = SystemClock.elapsedRealtime();
    }

    public void lap() {
        long lapTime = SystemClock.elapsedRealtime() - mStartedAt;
        mLaptimes.add(Long.valueOf(lapTime));
    }

    public void reset() {
        mChronoState = ChronoState.CS_IDLE;
        mStartedAt = SystemClock.elapsedRealtime();
        mLaptimes.clear();
    }

    public void tick() {
        if( mChronoState == ChronoState.CS_COUNTDOWN && mStartedAt < SystemClock.elapsedRealtime())
            mChronoState = ChronoState.CS_RUNNING;
    }

}
