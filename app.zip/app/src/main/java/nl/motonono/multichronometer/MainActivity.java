package nl.motonono.multichronometer;

import static nl.motonono.multichronometer.model.ChronoManager.RunMode.ALL_AT_ONCE;
import static nl.motonono.multichronometer.model.ChronoManager.RunMode.ONE_BY_ONE;
import static nl.motonono.multichronometer.model.ChronoManager.RunMode.TIMED_INTERVAL;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import nl.motonono.multichronometer.databinding.ActivityMainBinding;
import nl.motonono.multichronometer.model.Chronometer;
import nl.motonono.multichronometer.model.ChronoManager;
import nl.motonono.multichronometer.run.RunListAdapter;
import nl.motonono.multichronometer.settings.SettingsActivity;
import nl.motonono.multichronometer.startup.StartupListAdapter;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private StartupListAdapter startupListAdapter;
    private RunListAdapter runListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        RecyclerView startupRecyclerView = (RecyclerView) findViewById(R.id.startuplistView);
        startupListAdapter = new StartupListAdapter(ChronoManager.instance().getChronos());
        if(startupRecyclerView != null) {
            startupRecyclerView.setHasFixedSize(true);
            startupRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            startupRecyclerView.setAdapter(startupListAdapter);
        }

        RecyclerView runRecyclerView = (RecyclerView) findViewById(R.id.runListView);
        runListAdapter = new RunListAdapter(ChronoManager.instance());
        if(runRecyclerView != null ) {
            runRecyclerView.setHasFixedSize(true);
            runRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            runRecyclerView.setAdapter(runListAdapter);
        }

        Button btnAdd = (Button)  findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChronoManager.instance().getChronos().add(new Chronometer(ChronoManager.instance().getChronos().size()+1, "Enter name"));
                startupListAdapter.notifyDataSetChanged();
                runListAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}