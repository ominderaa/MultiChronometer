package nl.motonono.multichronometer.results;

import java.util.ArrayList;
import java.util.List;

import nl.motonono.multichronometer.model.Chronometer;
import nl.motonono.multichronometer.utils.TimeFormatter;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 * TODO: Replace all uses of this class before publishing your app.
 */
public class ResultContent {

    /**
     * An array of sample (placeholder) items.
     */
    public static final List<ResultItem> ITEMS = new ArrayList<ResultItem>();
    private static void addItem(ResultItem item) {
        ITEMS.add(item);
    }

    /**
     * A placeholder item representing a piece of content.
     */
    public static class ResultItem {
        public final String name;
        public final int lapnumber;
        public final long laptime;
        public final long totaltime;

        public ResultItem(String name, int lapnumber, long laptime, long totaltime) {
            this.name = name;
            this.lapnumber = lapnumber;
            this.laptime = laptime;
            this.totaltime = totaltime;
        }

        @Override
        public String toString() {
            String sLaptime = TimeFormatter.toText(laptime);

            return String.format("%s %d: %s %s", name, lapnumber, laptime, totaltime);
        }
    }
}