package nl.motonono.multichronometer.startup;

import static nl.motonono.multichronometer.model.ChronoManager.RunMode.ALL_AT_ONCE;
import static nl.motonono.multichronometer.model.ChronoManager.RunMode.ONE_BY_ONE;
import static nl.motonono.multichronometer.model.ChronoManager.RunMode.TIMED_INTERVAL;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import nl.motonono.multichronometer.R;
import nl.motonono.multichronometer.databinding.FragmentStartupBinding;
import nl.motonono.multichronometer.model.ChronoManager;

public class StartupFragment extends Fragment {

    private FragmentStartupBinding binding;
    private StartupListAdapter startupListAdapter;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentStartupBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView startupRecyclerView = (RecyclerView) view.findViewById(R.id.startuplistView);
        startupListAdapter = new StartupListAdapter(ChronoManager.instance().getChronos());
        if(startupRecyclerView != null) {
            startupRecyclerView.setHasFixedSize(true);
            startupRecyclerView.setLayoutManager(new LinearLayoutManager(null));
            startupRecyclerView.setAdapter(startupListAdapter);
        }

        binding.btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId=binding.rgStartType.getCheckedRadioButtonId();
                switch( selectedId ) {
                    case R.id.rbStartAll:   ChronoManager.instance().setRunmode(ALL_AT_ONCE); break;
                    case R.id.rbStartOne:   ChronoManager.instance().setRunmode(ONE_BY_ONE); break;
                    case R.id.rbStartTimed: ChronoManager.instance().setRunmode(TIMED_INTERVAL); break;
                }

                NavHostFragment.findNavController(StartupFragment.this)
                        .navigate(R.id.action_StartupFragment_to_RunFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}