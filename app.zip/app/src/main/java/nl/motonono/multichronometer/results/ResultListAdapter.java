package nl.motonono.multichronometer.results;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import nl.motonono.multichronometer.model.Chronometer;
import nl.motonono.multichronometer.results.ResultContent.ResultItem;
import nl.motonono.multichronometer.databinding.FragmentResultitemBinding;
import nl.motonono.multichronometer.utils.TimeFormatter;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link ResultItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class ResultListAdapter extends RecyclerView.Adapter<ResultListAdapter.ViewHolder> {

    private final List<ResultItem> mValues;

    public ResultListAdapter(List<ResultItem> items) {
        mValues = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        return new ViewHolder(FragmentResultitemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));

    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        ResultItem item = mValues.get(position);
        holder.mNameView.setText(item.name);
        holder.mLapnumberView.setText(String.valueOf(item.lapnumber));
        holder.mLaptimeView.setText(TimeFormatter.toText(item.laptime));
        holder.mTotaltimeView.setText(TimeFormatter.toText(item.totaltime));
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView mNameView;
        public final TextView mLapnumberView;
        public final TextView mLaptimeView;
        public final TextView mTotaltimeView;

        public ViewHolder(FragmentResultitemBinding binding) {
            super(binding.getRoot());
            mNameView = binding.txChronoName;
            mLapnumberView = binding.txLapnumber;
            mLaptimeView = binding.txLaptime;
            mTotaltimeView = binding.txTotaltime;
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mNameView.getText() + "'";
        }
    }
}