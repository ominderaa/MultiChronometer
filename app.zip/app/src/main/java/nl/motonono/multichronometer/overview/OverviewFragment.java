package nl.motonono.multichronometer.overview;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import nl.motonono.multichronometer.R;
import nl.motonono.multichronometer.utils.TimeFormatter;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OverviewFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OverviewFragment extends Fragment {

    private static final String ARG_NAME = "Name";
    private static final String ARG_LAPCOUNT = "lapcount";
    private static final String ARG_LAPTIME = "laptime";
    private static final String ARG_TOTALTIME = "totaltime";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String mParam3;
    private String mParam4;

    public OverviewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param name Parameter 1.
     * @param lapcount Parameter 2.
     * @param laptime Parameter 3.
     * @param totaltime Parameter 4.
     * @return A new instance of fragment OverviewFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OverviewFragment newInstance(String name, int lapcount, long laptime, long totaltime) {
        OverviewFragment fragment = new OverviewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_NAME, name);
        args.putString(ARG_LAPCOUNT, String.valueOf(lapcount));
        args.putString(ARG_LAPTIME, TimeFormatter.toText(laptime));
        args.putString(ARG_TOTALTIME, TimeFormatter.toText(totaltime));
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_NAME);
            mParam2 = getArguments().getString(ARG_LAPCOUNT);
            mParam3 = getArguments().getString(ARG_LAPTIME);
            mParam4 = getArguments().getString(ARG_TOTALTIME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_overview, container, false);
    }
}