# Multi Chronometer
Keep times for multiple athletes

This Android application is a simple chronometer for multiple athletes at the same time. 
It keeps times in 100-ths of a second. Create an unlimitted (well, ok, almost) number of chronometers and record lap times.
